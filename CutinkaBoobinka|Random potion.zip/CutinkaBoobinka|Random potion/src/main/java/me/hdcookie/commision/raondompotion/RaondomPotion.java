package me.hdcookie.commision.raondompotion;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Random;

public final class RaondomPotion extends JavaPlugin {
    private static RaondomPotion mainInstance;
    int thingy;


    @Override
    public void onEnable() {
        Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN+"RandomPotion Enabled");
        mainInstance = this;
        getConfig().options().copyDefaults();
        saveDefaultConfig();


        thingy = Bukkit.getScheduler().scheduleSyncRepeatingTask(RaondomPotion.getMainInstance(), new Runnable() {
            @Override
            public void run() {
                //Put code here
                for(Player player: Bukkit.getOnlinePlayers()){
                    if(player.hasPermission("randompotion.use")) {


                        int size = getConfig().getStringList("effects").size();
                        int number = new Random().nextInt(size);

                        String effect = (String) getConfig().getList("effects").get(number);
                        System.out.println(effect + " effect");

                        player.addPotionEffect(new PotionEffect(PotionEffectType.getByName(effect), getConfig().getInt("time") + 5, 1));
                    }
                }

            }
        },1, getConfig().getInt("time"));


    }

    @Override
    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage(ChatColor.RED+"RandomPotion Disabled");
    Bukkit.getScheduler().cancelTask(thingy);}
    public static RaondomPotion getMainInstance() {
        return mainInstance;
    }
}
