package me.hdcookie.commisions.kedy_bogan;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatShort implements Listener {

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event){
        FileConfiguration config = Kedy_bogan.getMainInstance().getConfig();


        for(int i = 0; i < config.getList("chat").size(); i++){

            String origional = (String) config.getList("chat").get(i);

            String[] parts = origional.split(":");
            String part1 = parts[0];
            String part2 = parts[1];

            if(event.getMessage().contains(part2)){

                event.setMessage(event.getMessage().replace(part2, part1));
            }

        }

    }
}
