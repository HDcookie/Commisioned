package me.hdcookie.commisions.kedy_bogan;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public final class Kedy_bogan extends JavaPlugin {
    private static Kedy_bogan kedy_bogan;

    @Override
    public void onEnable() {
        Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN+"kedy bogan's plugin enabled");
        kedy_bogan = this;
        Bukkit.getPluginManager().registerEvents(new Pack(),  this);
        Bukkit.getPluginManager().registerEvents( new ChatShort(), this);

        getConfig().options().copyDefaults();
        saveDefaultConfig();
    }

    @Override
    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage(ChatColor.RED+"kedy bogan's plugin disabled");
    }
    public static Kedy_bogan getMainInstance(){
        return kedy_bogan;
    }


}
