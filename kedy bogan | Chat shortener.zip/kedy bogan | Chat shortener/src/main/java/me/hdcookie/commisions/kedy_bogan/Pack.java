package me.hdcookie.commisions.kedy_bogan;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class Pack implements Listener {
    @EventHandler
    public void onJoin(PlayerJoinEvent event){
        event.getPlayer().setResourcePack(Kedy_bogan.getMainInstance().getConfig().getString("pack"));
    }
}
