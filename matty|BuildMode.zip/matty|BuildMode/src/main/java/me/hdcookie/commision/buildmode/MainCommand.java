package me.hdcookie.commision.buildmode;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;

public class MainCommand implements CommandExecutor {
    private final BuildMode buildMode;
    HashMap<Player, ItemStack[]> inventory = new HashMap<>();
    static HashMap<Player, ItemStack[]> armor = new HashMap<Player, ItemStack[]>();


    public MainCommand(BuildMode buildMode) {
        this.buildMode = buildMode;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(sender instanceof Player){
            Player player = (Player) sender;

            toggleGameMode(player);

        }else {sender.sendMessage(ChatColor.RED+"Error!  You must be a player to run this command");}
        return false;
    }

    private void toggleGameMode(Player player) {
        if(buildMode.isToggled.contains(player)) {
            buildMode.isToggled.remove(player);

            player.sendMessage(ChatColor.RED+"Build Mode DISABLED");
            player.setGameMode(GameMode.SURVIVAL);

            //Begin retrieving players inventory
            if(inventory.get(player) != null){
                player.getInventory().setContents(inventory.get(player));
            }else{player.sendMessage("Error Occured");}


            if (armor.get(player) != null){
                player.getInventory().setArmorContents(armor.get(player));
            }else{player.sendMessage("Error Occured");}


        } else {
            buildMode.isToggled.add(player);

            player.sendMessage(ChatColor.GREEN+"Build Mode ENABLED");
            player.setGameMode(GameMode.CREATIVE);

            //Begin saving player's inventory
            inventory.put(player, player.getInventory().getContents());
            armor.put(player, player.getInventory().getArmorContents());

            player.getInventory().clear();
        }
    }
}
