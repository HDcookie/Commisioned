package me.hdcookie.commision.buildmode;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;

public final class BuildMode extends JavaPlugin {
    ArrayList<Player> isToggled = new ArrayList<>();
    private static BuildMode mainInstance;

    @Override
    public void onEnable() {
        Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN+"Build Mode Enabled!");
        mainInstance = this;
        getCommand("buildMode").setExecutor(new MainCommand(this));

    }

    @Override
    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage(ChatColor.RED+"Build Mode Disabled!");
    }

    public static BuildMode getMainInstance() {
        return mainInstance;
    }
}
